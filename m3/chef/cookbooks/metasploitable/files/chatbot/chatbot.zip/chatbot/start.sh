#!/bin/sh

echo "Starting bot functions..."
nodejs /opt/chatbot/papa_smurf/functions.js &

echo "Starting bot client..."
nodejs /opt/chatbot/papa_smurf/chat_client.js &

echo "Starting chatroom cleaner"
/opt/chatbot/clear_chat.sh &

echo "ok"
